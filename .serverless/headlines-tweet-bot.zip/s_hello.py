import serverless_sdk
sdk = serverless_sdk.SDK(
    org_id='ashokb08',
    application_name='headlines-tweet-app',
    app_uid='XNZJ97vC7TkV6dFTW1',
    org_uid='Jv5SRdl1VB7CKqXfQ4',
    deployment_uid='7372ea25-d91f-4465-a86a-616b383edaa9',
    service_name='headlines-tweet-bot',
    should_log_meta=True,
    should_compress_logs=True,
    disable_aws_spans=False,
    disable_http_spans=False,
    stage_name='dev',
    plugin_version='4.4.1',
    disable_frameworks_instrumentation=False,
    serverless_platform_stage='prod'
)
handler_wrapper_kwargs = {'function_name': 'headlines-tweet-bot-dev-hello', 'timeout': 6}
try:
    user_handler = serverless_sdk.get_user_handler('handler.hello')
    handler = sdk.handler(user_handler, **handler_wrapper_kwargs)
except Exception as error:
    e = error
    def error_handler(event, context):
        raise e
    handler = sdk.handler(error_handler, **handler_wrapper_kwargs)
